void LoadData(){
unsigned char temp = 0;
unsigned char j = 0;
//int1  check_valid_data = 0;
WAIT_SECOND(5);
//--------------------------------------------
// LOAD CHUC NANG PHAN QUYEN TRUY CAP
   temp = read_eeprom(ADD_ADMIN_FUN);
   if(temp == 1)FLAG_ADMIN_FUN = 1;
   else FLAG_ADMIN_FUN = 0;
//--------------------------------------------
// LOAD DO DAI CUA CAC THONG SO
   L_O_PORT = read_eeprom(ADD_L_O_PORT);
   if(L_O_PORT > 5)        L_O_PORT = 5;
   fprintf(DEBUG,"\n\rL_O_PORT: %u",L_O_PORT);
   L_O_DNS  = read_eeprom(ADD_L_O_DNS);
   if(L_O_DNS > 15)        L_O_DNS = 15;
   fprintf(DEBUG,"\n\rL_O_DNS: %u",L_O_DNS);
//-------------------------------------------
   L_O_APN  = read_eeprom(ADD_L_O_APN);
   if(L_O_APN > 10)        L_O_APN = 10;
   fprintf(DEBUG,"\n\rL_O_APN: %u",L_O_APN);
   L_O_USER_GPRS = read_eeprom(ADD_L_O_USER_GPRS);
   if(L_O_USER_GPRS > 5)   L_O_USER_GPRS = 5;
   fprintf(DEBUG,"\n\rL_O_USER_GPRS: %u\r",L_O_USER_GPRS);
   L_O_PASS_GPRS = read_eeprom(ADD_L_O_PASS_GPRS);
   if(L_O_PASS_GPRS > 5)   L_O_PASS_GPRS = 5;
   fprintf(DEBUG,"\n\rL_O_PASS_GPRS: %u\r",L_O_PASS_GPRS);
//-------------------------------------------   
   L_O_ID = read_eeprom(ADD_L_O_ID);
   if(L_O_ID > 5)          L_O_ID = 5;
   fprintf(DEBUG,"\n\rL_O_ID: %u\r",L_O_ID);
//--------------------------------------------   
   L_O_USER_FTP = read_eeprom(ADD_L_O_USER_FTP);
   if(L_O_USER_FTP > 10)          L_O_USER_FTP = 10;
   fprintf(DEBUG,"\n\rL_O_USER_FTP: %u",L_O_USER_FTP);
   L_O_PASS_FTP = read_eeprom(ADD_L_O_PASS_FTP);
   if(L_O_PASS_FTP > 10)          L_O_PASS_FTP = 10;
   fprintf(DEBUG,"\n\rL_O_PASS_FTP: %u",L_O_PASS_FTP);
   L_O_FILE_FTP = read_eeprom(ADD_L_O_FILE_FTP);
   if(L_O_FILE_FTP > 20)          L_O_FILE_FTP = 20;
   fprintf(DEBUG,"\n\rL_O_FILE_FTP: %u\r",L_O_FILE_FTP);   
//--------------------------------------------
// LOAD PASS LOGIN VAO THIET BI
   fprintf(DEBUG,"\n\rPASS LOGIN: ");
   for(j=0;j<4;j++){
   PASS_LOGIN[j] = read_eeprom(ADD_PASS_LOGIN + j);
   if((PASS_LOGIN[j] < 33)||(PASS_LOGIN[j] > 122))PASS_LOGIN[j] = '1';
   fputc(PASS_LOGIN[j],DEBUG);
   }
//--------------------------------------------
// LOAD ID CUA THIET BI
   fprintf(DEBUG,"\n\rID: ");
   for(j=0;j<L_O_ID;j++){
   ID_GPRS[j] = read_eeprom(ADD_ID + j);
   if((ID_GPRS[j] < 33)||(ID_GPRS[j] > 122))ID_GPRS[j] = '1';
   fputc(ID_GPRS[j],DEBUG);
   }
//--------------------------------------------
// LOAD PORT KET NOI TOI SERVER
   fprintf(DEBUG,"\n\rPORT: ");
   for(j=0;j<L_O_PORT;j++){
   PORT_GPRS[j] = read_eeprom(ADD_PORT_SERVER + j);
   if((PORT_GPRS[j] < 48)||(PORT_GPRS[j] > 57))PORT_GPRS[j] = '1';
   fputc(PORT_GPRS[j],DEBUG);
   }
//--------------------------------------------   
// LOAD CAC THONG SO VAO MANG GPRS APN
   fprintf(DEBUG,"\n\rAPN: ");
   for(j=0;j<L_O_APN;j++){
   APN_GPRS[j] = read_eeprom(ADD_APN_GPRS + j);
   if((APN_GPRS[j] < 33)||(APN_GPRS[j] > 122))APN_GPRS[j] = '1';
   fputc(APN_GPRS[j],DEBUG);
   }
//--------------------------------------------   
// LOAD CAC THONG SO VAO MANG GPRS USER
   fprintf(DEBUG,"\n\rUSER APN :");
   for(j=0;j<L_O_USER_GPRS;j++){
   USER_GPRS[j] = read_eeprom(ADD_USER_GPRS + j);
   if((USER_GPRS[j] < 33)||(USER_GPRS[j] > 122))USER_GPRS[j] = '1';
   fputc(USER_GPRS[j],DEBUG);
   }
//--------------------------------------------   
// LOAD CAC THONG SO VAO MANG GPRS PASS
   fprintf(DEBUG,"\n\rPASS APN: ");
   for(j=0;j<L_O_PASS_GPRS;j++){
   PASS_GPRS[j] = read_eeprom(ADD_PASS_GPRS + j);
   if((PASS_GPRS[j] < 33)||(PASS_GPRS[j] > 122))PASS_GPRS[j] = '1';
   fputc(PASS_GPRS[j],DEBUG);
   }
//--------------------------------------------   
// LOAD CAC THONG SO VAO MANG GPRS DNS
   fprintf(DEBUG,"\n\rDNS: ");
   for(j=0;j<L_O_DNS;j++){
   DNS_SERVER[j] = read_eeprom(ADD_DNS + j);
   if((DNS_SERVER[j] < 33)||(DNS_SERVER[j] > 122))DNS_SERVER[j] = '1';
   fputc(DNS_SERVER[j],DEBUG);
   }
//--------------------------------------------   
// LOAD CAC THONG SO DOWNLOAD FILE  USER FTP
   fprintf(DEBUG,"\n\rUSER FTP: ");
   for(j=0;j<L_O_USER_FTP;j++){
   USER_FTP[j] = read_eeprom(ADD_USER_FTP + j);
   if((USER_FTP[j] < 33)||(USER_FTP[j] > 122))USER_FTP[j] = '1';
   fputc(USER_FTP[j],DEBUG);
   }
//--------------------------------------------   
// LOAD CAC THONG SO DOWNLOAD FILE  PASS FTP
   fprintf(DEBUG,"\n\rPASS FTP: ");
   for(j=0;j<L_O_PASS_FTP;j++){
   PASS_FTP[j] = read_eeprom(ADD_PASS_FTP + j);
   if((PASS_FTP[j] < 33)||(PASS_FTP[j] > 122))PASS_FTP[j] = '1';
   fputc(PASS_FTP[j],DEBUG);
   }
// LOAD CAC THONG SO DOWNLOAD FILE  FILE FTP
   fprintf(DEBUG,"\n\rFILE FTP: ");
   for(j=0;j<L_O_FILE_FTP;j++){
   FILE_FTP[j] = read_eeprom(ADD_FILE_FTP + j);
   if((FILE_FTP[j] < 33)||(FILE_FTP[j] > 122))FILE_FTP[j] = '1';
   fputc(FILE_FTP[j],DEBUG);
   }
//--------------------------------------------

}
