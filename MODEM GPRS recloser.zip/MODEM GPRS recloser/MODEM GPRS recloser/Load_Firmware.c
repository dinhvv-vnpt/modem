int   config_FTP(){
int1 temp_check_bolean = 0;
unsigned char j = 0;
prepare_for_check_OK();
   fprintf(PORT1,"AT+SAPBR=3,1,\"Contype\",\"GPRS\"\r");      //908
   temp_check_bolean = check_OK_from_ME();
   //----------------------------
   if(temp_check_bolean == 0){ 
   fprintf(PORT1,"AT+SAPBR=3,1,\"APN\",\"");      //908
    for(j=0;j<L_O_APN;j++)fputc(APN_GPRS[j],PORT1);
   fprintf(PORT1,"\"\r");
   temp_check_bolean = check_OK_from_ME();
   }
   //----------------------------
   if(temp_check_bolean == 0){ 
   fprintf(PORT1,"AT+SAPBR=3,1,\"USER\",\"");      //908
   for(j=0;j<L_O_USER_GPRS;j++)fputc(USER_GPRS[j],PORT1);
   fprintf(PORT1,"\"\r");
   temp_check_bolean = check_OK_from_ME();
   }
   //----------------------------
   if(temp_check_bolean == 0){ 
   fprintf(PORT1,"AT+SAPBR=3,1,\"PWD\",\"");      //908
   for(j=0;j<L_O_PASS_GPRS;j++)fputc(PASS_GPRS[j],PORT1);
   fprintf(PORT1,"\"\r");
   temp_check_bolean = check_OK_from_ME();
   }
   //---------------------------
//!   if(temp_check_bolean == 0){ 
//!   fprintf(PORT1,"AT+SAPBR=1,1\r");      //908
//!   temp_check_bolean = check_OK_from_ME();
//!   }   
   if(temp_check_bolean == 0){ 
   fprintf(PORT1,"AT+FTPCID=1\r");      //908
   temp_check_bolean = check_OK_from_ME();
   }
   if(temp_check_bolean == 0){   // SIM5320
   prepare_for_check_OK();
// fprintf(PORT1,"AT+CFTPSERV=\"");    // IP HOST FTP   5320
   fprintf(PORT1,"AT+FTPSERV=\"");    // IP HOST FTP      908
      for(j=0;j<L_O_DNS;j++)fputc(DNS_SERVER[j],PORT1);
   fprintf(PORT1,"\"\r");
   temp_check_bolean = check_OK_from_ME();
   }
   if(temp_check_bolean == 0){   // SIM5320
   prepare_for_check_OK(); 
   fprintf(PORT1,"AT+FTPPORT=21\r");      //908
   temp_check_bolean = check_OK_from_ME();
   }
   if(temp_check_bolean == 0){   // SIM5320 USER FTP SERVER
   prepare_for_check_OK();
 //fprintf(PORT1,"AT+CFTPUN=\"");    // 5320
   fprintf(PORT1,"AT+FTPUN=\"");      // 908
      for(j=0;j<L_O_USER_FTP;j++)fputc(USER_FTP[j],PORT1);
   fprintf(PORT1,"\"\r");
   temp_check_bolean = check_OK_from_ME();
   }
   if(temp_check_bolean == 0){   // SIM5320 PASS FTP SERVER
   prepare_for_check_OK();
 //fprintf(PORT1,"AT+CFTPPW=\"");      // 5320
   fprintf(PORT1,"AT+FTPPW=\"");
      for(j=0;j<L_O_PASS_FTP;j++)fputc(PASS_FTP[j],PORT1);
   fprintf(PORT1,"\"\r");      
   temp_check_bolean = check_OK_from_ME();
   } 
   if(temp_check_bolean == 0){ 
   fprintf(PORT1,"AT+FTPSCONT\r");      //908
   temp_check_bolean = check_OK_from_ME();
   }
return(temp_check_bolean);
}
//------------------------------------------------------------------------------
int download_FTP(){
int1 temp_check_bolean = 0;
unsigned char j = 0;
   prepare_for_check_OK();
   fprintf(PORT1,"AT+SAPBR=1,1\r");
   temp_check_bolean = check_OK_from_ME();
   if(temp_check_bolean == 0){   // SIM5320 PASS FTP SERVER
   prepare_for_check_OK();
   fprintf(PORT1,"AT+FTPGETNAME=\"");
      for(j=0;j<L_O_FILE_FTP;j++)fputc(FILE_FTP[j],PORT1);
   fprintf(PORT1,"\"\r");      
   temp_check_bolean = check_OK_from_ME();
   }  
   if(temp_check_bolean == 0){   // SIM5320 PASS FTP SERVER
   prepare_for_check_OK();
   fprintf(PORT1,"AT+FTPGETPATH=\"/\"\r");
   temp_check_bolean = check_OK_from_ME();
   }  
   if(temp_check_bolean == 0){   // SIM5320 PASS FTP SERVER
   prepare_for_check_OK();
   fprintf(PORT1,"AT+FTPGET=1\r");
   temp_check_bolean = check_OK_from_ME();
   } 
   WAIT_SECOND (2) ;
return(temp_check_bolean);
}
//------------------------------------------------------------------------------
// START CODE---BYTE COUNT---ADDRESS---RECORD TYPE---DATA---CHECKSUM
int Program_To_Pic18F67J60(){
int1 temp_check_bolean = 0;
   if(temp_check_bolean == 0){   // SIM5320 PASS FTP SERVER
   prepare_for_check_OK();
   fprintf(PORT1,"AT+FTPGET=2,99\r");
   temp_check_bolean = check_OK_from_ME();
   } 
return(temp_check_bolean);
}
//------------------------------------------------------------------------------
int1 Checksum_Data_From_FTP(){
int1 temp_check_bolean = 0;
unsigned char temp = 0;
unsigned char j = 0;
//  CHECKSUM SO KY TU THU DUOC
   for(j=1;j < L_O_DATA_FROM_SERVER-1; j++){
      temp = temp + BUFF_DATA_RECEIVE_FTP[j];
   }
   temp = ~temp;
   temp = temp+1;    // LAY SO BU 2 
   if(temp != BUFF_DATA_RECEIVE_FTP[L_O_DATA_FROM_SERVER])temp_check_bolean = 1;    // CHECKSUM VALID 
return(temp_check_bolean);
}
//------------------------------------------------------------------------------
int1 Emty_Buffer_File_Ftp(){
int1 temp_check_bolean = 0;
unsigned char i = 0;
//   fprintf(DEBUG,"\n\rEase Buffer FTP: \n\r");
   for(i=0;i < MAX_DATA_RECEIVE_FROM_FTP; i++){
 //     fputc(BUFF_DATA_RECEIVE_FTP[i],DEBUG);
      BUFF_DATA_RECEIVE_FTP[i] = 0;
   }
   FLAG_DATA_FROM_FTP_START = 0;
   FLAG_DATA_FROM_FTP_SUCCESS = 0;
   L_O_DATA_FROM_FTP = 0;
   data_ftp_index = 0;
return(temp_check_bolean);
}
//------------------------------------------------------------------------------
int1 Read_File_Ftp(){
int1 temp_check_bolean = 0;
unsigned char i = 0;
//   fprintf(DEBUG,"\n\rDisplay Data FTP: \n\r");
   for(i=7;i < L_O_DATA_FROM_FTP-2; i++){
   fputc(BUFF_DATA_RECEIVE_FTP[i],DEBUG);
   }
return(temp_check_bolean);
}
