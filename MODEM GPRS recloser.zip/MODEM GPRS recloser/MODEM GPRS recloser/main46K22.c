#include <main46K22.h>
unsigned char tick_second = 0,tick_100ms = 0;

#INT_RDA
void rs485(){
unsigned char value;
value = fgetc(PORT1);
fputc(value,DEBUG);
}

#INT_RDA2
void rs232_rda2(){
unsigned char value;
value = fgetc(PORT2);
fputc(value,DEBUG);
}


#int_timer1
void  TIMER1_isr(VOID)
{
   set_timer3(65535-23150);   // ngat xay ra sau 100ms
   
//   output_toggle(PIN_B3);
   ++tick_100ms;
   if(tick_100ms > 200){
      ++tick_second;
      tick_100ms = 0;
      
   }
   if(tick_second > 200)tick_second = 0;
}
void main(){
   
setup_timer_1(T1_INTERNAL|T1_DIV_BY_8);   // setup interrupts
enable_interrupts(INT_TIMER1);
disable_interrupts(INT_RDA);
disable_interrupts(INT_RDA2);
enable_interrupts (GLOBAL);
//output_high(PIN_B3); 
   fprintf(DEBUG,"\n\rSTART DEBUG\n\r");
//   setup_timer_4(T4_DISABLED,0,1);
//   setup_comparator(NC_NC_NC_NC);// This device COMP currently not supported by the PICWizard
   
   while(1){
      output_high(PIN_B3); 
      enable_interrupts(INT_RDA);
      fprintf(PORT1,"\n\r@TEST PORT1 TO ETHERNET\n\r");
      
      delay_ms(2000);
      disable_interrupts(INT_RDA);
      delay_ms(10);
      enable_interrupts(INT_RDA2);
      fprintf(PORT2,"\n\rTEST PORT2 TO SIM908\n\r");
      delay_ms(1000);
      disable_interrupts(INT_RDA2);
      delay_ms(10);
   }

}
