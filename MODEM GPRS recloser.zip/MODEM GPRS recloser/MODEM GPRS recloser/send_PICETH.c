int1 Send_Data_To_PICETH(){
int1 temp_check_bolean = 0;
   delay_ms(100);
   prepare_for_check_OK();
   fprintf(PICETH,"/?1!\r\n");
   temp_check_bolean = check_OK_from_ME();
   //TON THOI GIAN BAO NHIEU GIAY
return(temp_check_bolean);
}
//------------------------------------------------------------------------------
void           Clear_Buffer_From_Ethernet(){
unsigned int16 i = 0;
for (i = 0; i < MAX_DATA_SEND_SERVER; i++);DATA_SEND_TO_SERVER[i] = 0;
L_O_DATA_FROM_PICETH = 0;
}
//------------------------------------------------------------------------------

