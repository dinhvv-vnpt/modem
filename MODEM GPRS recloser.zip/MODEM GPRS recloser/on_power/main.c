#include <main.h>
#int_timer1
void  TIMER1_isr(VOID){
   output_toggle(PIN_A1);
}

void main()
{
enable_interrupts (INT_TIMER1);
enable_interrupts(INT_RDA);
enable_interrupts(INT_RDA2);
setup_timer_1 (T1_INTERNAL|T1_DIV_BY_8); //104 ms overflow
enable_interrupts (GLOBAL);
output_high(PIN_D3);
delay_ms(3000);
output_low(PIN_D3);
while(1)
{
}

}

