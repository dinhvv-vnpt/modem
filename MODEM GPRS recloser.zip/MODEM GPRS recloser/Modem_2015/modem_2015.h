#include <18F45K22.h>
#device adc=10
#FUSES NOWDT                    //No Watch Dog Timer
//#FUSES WDT128                   //Watch Dog Timer uses 1:128 Postscale
#FUSES HSH                      //High speed Osc, high power 16MHz-25MHz
#FUSES NOPLLEN                  //4X HW PLL disabled, 4X PLL enabled in software
//#FUSES NOBROWNOUT               //No brownout reset
//!#FUSES WDT_NOSLEEP              //Watch Dog Timer, disabled during SLEEP
//#FUSES NOLVP                    //No low voltage prgming, B3(PIC16) or B5(PIC18) used for I/O
//#FUSES NOXINST                  //Extended set extension and Indexed Addressing mode disabled (Legacy mode)
#use delay(clock=20000000)
#use rs232(baud=38400,parity=N,xmit=PIN_B7,rcv=PIN_B6,bits=8,FORCE_SW,stream=DEBUG)
#use rs232(baud=19200,UART1,parity=N,xmit=PIN_C6,rcv=PIN_C7,bits=8,stream=PICETH,errors)
#use rs232(baud=19200,UART2,parity=N,xmit=PIN_D6,rcv=PIN_D7,bits=8,stream=PORT1,errors)

//------------------------------------------------------------------------------
#rom 0x2100 = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}
//------------------------------------------------------------------------------
//       BANG DIA CHI EEPROM
///************** 1 byte ***************
#define        ADD_ADMIN_FUN        1
///************** 4 byte ***************
#define        ADD_PASS_LOGIN       2
///************** 11 byte ***************
#define        ADD_L_O_APN          6 
#define        ADD_APN_GPRS         7
///************** 6 byte ***************
#define        ADD_L_O_PORT         17
#define        ADD_PORT_SERVER      18
///************** 16 byte ***************
#define        ADD_L_O_DNS          23
#define        ADD_DNS              24
///************** 6 byte ***************
#define        ADD_L_O_ID           39
#define        ADD_ID               40
///************** 6 byte ***************
#define        ADD_L_O_PASS_GPRS    45
#define        ADD_PASS_GPRS        46
///************** 6 byte ***************
#define        ADD_L_O_USER_GPRS    51
#define        ADD_USER_GPRS        52
///************** 11 byte ***************
#define        ADD_L_O_USER_FTP     57
#define        ADD_USER_FTP         58
///************** 11 byte ***************
#define        ADD_L_O_PASS_FTP     69
#define        ADD_PASS_FTP         70
///************** 11 byte ***************
#define        ADD_L_O_FILE_FTP     81
#define        ADD_FILE_FTP         82
//------------------------------------------------------------------------------
// KHAI BAO CAC CHAN CHUC NANG
#define        SWITCH_POWER      PIN_D3
#define        SWITCH_POWER_ON   output_high(SWITCH_POWER)
#define        SWITCH_POWER_OFF  output_low(SWITCH_POWER)

#define        CS_RS232             PIN_B3
#define        EN_MODEM_TO_ETH      output_high(CS_RS232)
#define        DIS_MODEM_TO_ETH     output_low(CS_RS232)

//!#define        WATCH_DOG            PIN_B4
//!#define        RESERT_WATCH_DOG     output_toggle(WATCH_DOG)

#define        ERROR_LED            PIN_B2
#define        ERROR_LED_ON         output_low(ERROR_LED)   
#define        ERROR_LED_OFF        output_high(ERROR_LED) 

//!
#define        PIN_DTR              PIN_B4
#define        PIN_DTR_ON           output_high(PIN_DTR)
#define        PIN_DTR_OFF          output_low(PIN_DTR)
#define        PIN_DTR_TOGGLE       output_toggle(PIN_DTR)
//-------------------------------pin mode---------------------------------------
#define        PIN_MODE_ON           output_high(PIN_B0)
#define        PIN_MODE_OFF          output_low(PIN_B0)

//------------------------------------------------------------------------------
//       CAC HANG SO SU DUNG TRONG CHUONG TRINH
#define        TIMEOUT                          10 // 500 ms
#define        MAX_COUNT_ERROR                  3
#define        MAX_COUNT_ERROR_TCP              5
#define        MAX_COUNT_ERROR_PICETH           2
#define        MAX_DATA_SEND_SERVER             300
#define        MAX_DATA_RECEIVE_FROM_SERVER     300
#define        MAX_DATA_RECEIVE_FROM_FTP        300
#define        MAX_DATA_PROG_TO_PIC             30
#define        MAX_COUNT_CHANGE_TASK            150
//------------------------------------------------------------------------------
unsigned int8  count_ERROR = 0;
unsigned int8  COUNT_TCP_ERROR = 0;
unsigned int8  COUNT_CHANGE_TASK = 0;
//------------------------------------------------------------------------------
//   CAC BIEN DINH THOI GIAN
unsigned int8  count_to_release_timeout = 0;
unsigned int8  tick_100ms   = 0;
unsigned int8  tick_second = 0;
unsigned int8  count_WAIT_MINUTE = 0;
unsigned int8  count_WAIT_SECOND = 0;
unsigned int8  tick_minute = 0;
unsigned int8  time_max_connect = 0;
//------------------------------------------------------------------------------
//    CAC HAM DINH THOI GIAN
int1           WAIT_MINUTE(unsigned int8 minute);
int1           WAIT_SECOND(unsigned int8 second);
int1           FLAG_5_MINUTE = 0;
//------------------------------------------------------------------------------
//    CAC HAM DIEU KHIEN HOAT DONG CUA MODULE
int1           check_device_POWER_ON();
int1           power_on_sim5218();
int1           config_module_sim5218();
int1           reset_module();
int1           check_sim_operation();
//------------------------------------------------------------------------------
//    CAC HAM SU DUNG DE PROGRAM CHO PIC18F67J60
int1           Process_Data_From_Server();
int1           Emty_Buffer_From_Server();
//------------------------------------------------------------------------------
int1           check_function_operation = 0;
//------------------------------------------------------------------------------
//   CAC HAM KIEM TRA DIEU KIEN TU 232
int1           wait_OK_IRA = 0;
int1           wait_OK_from_ME = 0;
void           prepare_for_check_OK();
int1           check_OK_from_ME();
//------------------------------------------------------------------------------
// CAC HAM DUOC SU DUNG CHO KET NOI TCP/IP
int1           Connect_TCP();
int1           Send_Data_To_Server();
//------------------------------------------------------------------------------
void           Clear_Buffer_From_Ethernet();
//------------------------------------------------------------------------------
//    CAC BIEN SU DUNG DE XU LY TIN NHAN NHAN VE TU MODULE SIM
int1           FLAG_ADMIN_FUN    = 0;
int1           FLAG_ADMIN_ACCESS = 0;
int1           FLAG_USER_ACCESS  = 0;
int1           FLAG_SMS_START    = 0;
int1           FLAG_SMS_SUCCESS  = 0;
int1           FLAG_SEND_SMS     = 0;
int1           FLAG_SEND_DATA_TO_RECLOSER = 0;

int1           FLAG_DATA_FROM_SERVER_START = 0;
int1           FLAG_DATA_FROM_SERVER_SUCCESS = 0;
unsigned char  BUFF_DATA_SMS[MAX_DATA_SEND_SERVER]; 
unsigned char  DATA_SEND_TO_SERVER[MAX_DATA_SEND_SERVER];
unsigned char  BUFF_DATA_RECEIVE_SERVER[MAX_DATA_RECEIVE_FROM_SERVER]; 
unsigned char  BUFF_DATA_TEMP[10];

//---------------------------------------
unsigned char  PHONE_NUMBER[15];
unsigned char  NUM_PHONE1[15];
unsigned char  NUM_PHONE2[15];
unsigned char  NUM_PHONE3[15];
//---------------------------------------
unsigned char  PASS_LOGIN[4];
unsigned char  APN_GPRS[10];
unsigned char  USER_GPRS[5];
unsigned char  PASS_GPRS[5];
unsigned char  USER_FTP[10];
unsigned char  PASS_FTP[10];
unsigned char  FILE_FTP[20];
unsigned char  PORT_GPRS[5];
unsigned char  ID_GPRS[5];
unsigned char  TIME_GPRS[10];
unsigned char  DNS_SERVER[15];
//---------------------------------------
unsigned char  DATA_SMS[50];  // NOI DUNG TIN NHAN
unsigned char  sms_index = 0;
unsigned char  data_server_index = 0;
unsigned char  data_temp_index = 0;
unsigned int16 L_O_DATA_FROM_PICETH = 0;
unsigned char  L_O_BUFF = 0;    // DO DAI CUA BUFFER TIN NHAN
unsigned char  L_O_PHONE = 0;    // DO DAI CUA SO DIEN THOAI
unsigned char  L_O_SMS = 0;    // DO DAI CUA NOI DUNG TIN NHAN
unsigned char  L_O_APN =0;
unsigned char  L_O_USER_GPRS =0;
unsigned char  L_O_PASS_GPRS =0;
unsigned char  L_O_USER_FTP =0;
unsigned char  L_O_PASS_FTP =0;
unsigned char  L_O_FILE_FTP =0;
unsigned char  L_O_ID = 0;
unsigned char  L_O_PORT = 0;
unsigned char  L_O_DNS = 0;

//------------------------------------------------------------------------------
int1           READ_SMS();
int1           DELETE_ALL_SMS();
void           SMS_PROCESS();
int            SEND_SMS_TO_USER();
//------------------------------------------------------------------------------
//   CAC TRANG THAI HOAT DONG CUA THIET BI
typedef enum{POWER_UP, POWER_DOWN, CONFIG_DEVICE} dDEVICE_STARTUP;
dDEVICE_STARTUP DEVICE_STARTUP, BEFORE_STARTUP;
typedef enum{DEVICE_READY, DEVICE_REQUEST_PICETH, DEVICE_CHECK_SMS, DEVICE_CONFIG, DEVICE_ERROR,RESET_MODULE_SIM, RESTORE_DEAULT} dDEVICE_STATE;
dDEVICE_STATE DEVICE_STATE,BEFORE_STATE;
typedef enum{SMS_IDLE,SET_GPRS,SET_DNS,SET_PASS,SET_FUNCTION,SET_LOCAL,SET_SEND,SET_USER,SET_PHONE,SET_TIME,SET_ID,SET_FTP,SET_FILE} dDEVICE_PARAMETER;
dDEVICE_PARAMETER SMS_STATE = SMS_IDLE;
typedef enum{TCP_IDLE,TCP_CONNECT,TCP_DISCONNECT,TCP_CONNECTING,TCP_ERROR,TCP_START} dSTATE_TCP;
dSTATE_TCP  STATE_TCP = TCP_IDLE;
//------------------------------------------------------------------------------
void LoadData();
//------------------------------------------------------------------------------
void blink_led(unsigned int8 n_flash_led,unsigned int8 delay_flash_led){
   unsigned int8 g;
   for(g=0;g<n_flash_led;g++)
   {
     // output_toggle(LED_STATUS);
      delay_ms(delay_flash_led);
     // output_toggle(LED_STATUS);
      delay_ms(delay_flash_led);
   }     
}
//------------------------------------------------------------------------------

