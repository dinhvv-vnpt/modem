int1 Connect_TCP(){
int1 temp_check_bolean = 0;
unsigned char j = 0;
   switch(STATE_TCP){
      CASE TCP_IDLE:{
//!            fprintf(PORT1,"AT&D1\r");
//!            WAIT_SECOND(1);
//!      delay_ms(1000);
//!      fputc('+',PORT1);delay_ms(100);
//!      fputc('+',PORT1);delay_ms(100);
//!      fputc('+',PORT1);delay_ms(500);
//!      fprintf (DEBUG, "\n\rTCP IDLE: \n\r") ;
//!         fprintf(DEBUG,"AT+CIPSHUT\r\n");
//!         fprintf(PORT1,"AT+CIPSHUT\r");
//!         WAIT_SECOND(3);
//!         fprintf(DEBUG,"AT+CIPSTATUS\r\n");
//!         fprintf(PORT1,"AT+CIPSTATUS\r");
//!         WAIT_SECOND(3);
//!         if(temp_check_bolean == 0){ 
            prepare_for_check_OK();
            fprintf(DEBUG,"\n\rAT+CIPMODE=1\n\r");
            fprintf(PORT1,"AT+CIPMODE=1\r");
            temp_check_bolean = check_OK_from_ME();
//!         }
//!         if(temp_check_bolean == 0){ 
//!            prepare_for_check_OK();
//!            fprintf(PORT1,"AT+CIPSPRT=1\r");
//!            temp_check_bolean = check_OK_from_ME();
//!         }
//!         if(temp_check_bolean == 0){ 
//!            prepare_for_check_OK();
//!            fprintf(PORT1,"AT+CIPQSEND=1\r");
//!            temp_check_bolean = check_OK_from_ME();
//!         }         

//!         if(temp_check_bolean == 0){      // SIM 908
//!            prepare_for_check_OK();
//!            fprintf(PORT1,"AT+CIPMUX=0\r");
//!            temp_check_bolean = check_OK_from_ME();
//!         }
//!         if(temp_check_bolean == 0){   //TCP connection profile
//!            prepare_for_check_OK();    // SIM908
//!            fprintf(DEBUG,"AT+CSTT=\"");
//!            fprintf(PORT1,"AT+CSTT=\"");
//!            for(j=0;j<L_O_APN;j++)fputc(APN_GPRS[j],PORT1);
//!            fprintf(PORT1,"\",\"");
//!            for(j=0;j<L_O_USER_GPRS;j++)fputc(USER_GPRS[j],PORT1);
//!            fprintf(PORT1,"\",\"");
//!            for(j=0;j<L_O_PASS_GPRS;j++)fputc(PASS_GPRS[j],PORT1);
//!            fprintf(PORT1,"\"\r");
//!            temp_check_bolean = check_OK_from_ME();
//!         } 
//!         if(temp_check_bolean == 0){   // THIET LAP CHE DO TIN NHAN TEXT
//!            prepare_for_check_OK();
//!            fprintf(DEBUG,"AT+CIICR\r\n");
//!            fprintf(PORT1,"AT+CIICR\r");
//!            temp_check_bolean = check_OK_from_ME();
//!         }  // 01 04 00 0A 00 1E 50 00  8688
//!        // if(temp_check_bolean == 0){   
//!        //    prepare_for_check_OK();
//!            fprintf(DEBUG,"AT+CIFSR\r\n");
//!            fprintf(PORT1,"AT+CIFSR\r");
//!            WAIT_SECOND(3);
//!        //    temp_check_bolean = check_OK_from_ME();
//!        // }
//!       
         if(temp_check_bolean == 0)   STATE_TCP = TCP_START;
         else STATE_TCP = TCP_ERROR;
         break;
      }
      CASE TCP_START:{
        if(temp_check_bolean == 0){
            prepare_for_check_OK();
            fprintf(DEBUG,"\n\rAT+NETOPEN=");
            fputc('"',DEBUG);
            fputc('T',DEBUG);
            fputc('C',DEBUG);
            fputc('P',DEBUG);
            fputc('"',DEBUG);
            fputc(',',DEBUG);
            for(j=0;j<L_O_PORT;j++)fputc(PORT_GPRS[j],DEBUG);
            fprintf(DEBUG,"\n\r");
            fprintf(PORT1,"AT+NETOPEN=");
            fputc('"',PORT1);
            fputc('T',PORT1);
            fputc('C',PORT1);
            fputc('P',PORT1);
            fputc('"',PORT1);
            fputc(',',PORT1);
            for(j=0;j<L_O_PORT;j++)fputc(PORT_GPRS[j],PORT1);
            fputc('\r',PORT1);
//!         fprintf(PORT1,"AT+NETOPEN=\"TCP\",8687\r");
          delay_ms(5000);
          temp_check_bolean = check_OK_from_ME();
         }
        if(temp_check_bolean == 1) 
              STATE_TCP = TCP_ERROR;
         if(temp_check_bolean == 0){
         prepare_for_check_OK();
         
          //
         fprintf(DEBUG,"\n\rTCPCONNECTING... \n\r");
         fprintf(PORT1,"AT+TCPCONNECT=");
         fputc('"',PORT1);
         for(j=0;j<L_O_DNS;j++)fputc(DNS_SERVER[j],PORT1);
         fputc('"',PORT1);
         fputc(',',PORT1);
         for(j=0;j<L_O_PORT;j++)fputc(PORT_GPRS[j],PORT1);
         fputc('\r',PORT1);
//!         fprintf(PORT1,"AT+TCPCONNECT=\"112.213.91.34\",8687\r");
         temp_check_bolean = check_OK_from_ME();
         }
         
         if(temp_check_bolean == 0)   
            STATE_TCP = TCP_CONNECT;
         else 
            STATE_TCP = TCP_ERROR;
         
         break;
      }
      CASE TCP_CONNECT:{
 //     ERROR_ON;
      COUNT_TCP_ERROR = 0;
      temp_check_bolean = 0;
      prepare_for_check_OK();
      fprintf (DEBUG, "%u\n\r",COUNT_CHANGE_TASK) ;
         //GUI GOI TIN DI TRONG TASK NAY
      Emty_Buffer_From_Server();
      // KIEM TRA CHAC CHAN CO TRANG THAI CONNECT ROI MOI CHO PHEP GUI DU LIEU TOI METER
      //fprintf (PORT1, "\n\rTEST LUNG TUN TCP CONNECTED: \n\r") ;
//!          if(FLAG_RECEIV_ETH_SUCCESS == 1){
//!            temp_check_bolean = Send_Data_To_Server();
//!            }
//!         if(temp_check_bolean == 0){   
//!         // GUI THANH CONG THI XOA CO   
//!            FLAG_RECEIV_ETH_SUCCESS = 0;
//!            STATE_TCP = TCP_CONNECT;
//!            L_O_DATA_FROM_PICETH = 0;
//!         }
//!         else STATE_TCP = TCP_DISCONNECT;
      break;
      }
      CASE TCP_DISCONNECT:{
      delay_ms(1000);
      fputc('+',PORT1);delay_ms(100);
      fputc('+',PORT1);delay_ms(100);
      fputc('+',PORT1);delay_ms(500);
      
      fprintf (DEBUG, "\n\rTCP DISCONNECT: \n\r") ;
      WAIT_SECOND(1);
      fprintf(DEBUG,"AT+TCPCLOSE\r"); 
     // fprintf(PORT1,"AT+CIPCLOSE\r");  //SIM908
      fprintf(PORT1,"AT+TCPCLOSE\r");  //SIM5320
      WAIT_SECOND(3);
      STATE_TCP = TCP_START;
      DEVICE_STATE = DEVICE_CHECK_SMS;
      break;
      }
      CASE TCP_ERROR:{
      ++COUNT_TCP_ERROR;
      delay_ms(1000);
      fputc('+',PORT1);delay_ms(100);
      fputc('+',PORT1);delay_ms(100);
      fputc('+',PORT1);delay_ms(500);
      
      fprintf (DEBUG, "\n\rTCP ERROR: %u\n\r",COUNT_TCP_ERROR) ;
      fprintf(DEBUG,"AT+CIPSHUT\r");//SIM908
      fprintf(PORT1,"AT+CIPSHUT\r");//SIM908
     // fprintf(PORT1,"AT+NETCLOSE\r");  
      WAIT_SECOND(3);
      STATE_TCP = TCP_IDLE;
      break;
      }      
   }
   if(COUNT_TCP_ERROR > MAX_COUNT_ERROR_TCP){ DEVICE_STATE = RESET_MODULE_SIM;}
   return(temp_check_bolean);
}
//------------------------------------------------------------------------------
int1 Send_Data_To_Server(){
int1 temp_check_bolean = 0;
unsigned char index_data = 0;
   prepare_for_check_OK();
/*   fprintf(PORT1,"AT+TCPWRITE=40\r");
   WAIT_SECOND(2);
   fprintf(PORT1,"@82,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15#\r");*/
//   for(index_data = 0; index_data < MAX_DATA_SEND_SERVER; index_data++){
//      fputc(DATA_SEND_TO_SERVER[index_data],PORT1);
//   }
//fprintf(DEBUG,"AT+CIPSEND\r\n");
fprintf(PORT1,"AT+CIPSEND\r");
WAIT_SECOND(2);
      for(index_data = 0; index_data < L_O_DATA_FROM_PICETH; index_data++){
         fputc(DATA_SEND_TO_SERVER[index_data],PORT1);
       //  delay_ms(1);
      }
//fprintf(PORT1,"@82,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15#");
fputc('#',PORT1);
WAIT_SECOND(2);
fputc(26,PORT1);
temp_check_bolean = check_OK_from_ME();
//------------------------------

//------------------------------
return(temp_check_bolean);   
}
//------------------------------------------------------------------------------
int1 Process_Data_From_Server(){
int1 temp_check_bolean = 0;

//CAC CAU TRUC DUOC THIET LAP TU SERVER <>
if(BUFF_DATA_TEMP[0] == 'C' && BUFF_DATA_TEMP[1] == 'L' && BUFF_DATA_TEMP[2] == 'O' && BUFF_DATA_TEMP[3] == 'S' && BUFF_DATA_TEMP[4] == 'E' && BUFF_DATA_TEMP[5] == 'D')
{
fprintf(DEBUG,"RECEIVE CLOSED\r\n");

STATE_TCP = TCP_DISCONNECT;  // NHAN DUOC CLOSED TU SERVER
}

if(BUFF_DATA_TEMP[0] == 'C' && BUFF_DATA_TEMP[1] == 'O' && BUFF_DATA_TEMP[2] == 'N' && BUFF_DATA_TEMP[3] == 'N' && BUFF_DATA_TEMP[4] == 'E' && BUFF_DATA_TEMP[5] == 'C') 
// TRANG THAI CONNECT OK
{  
fprintf(DEBUG,"\r\nCONNECT OK \r\n");
STATE_TCP = TCP_CONNECT;
COUNT_CHANGE_TASK = 0;
FLAG_SEND_DATA_TO_RECLOSER = 1;
}
FLAG_DATA_FROM_SERVER_START = 0;
FLAG_DATA_FROM_SERVER_SUCCESS = 0;
return(temp_check_bolean);
}
//------------------------------------------------------------------------------
int1 Emty_Buffer_From_Server(){
int1 temp_check_bolean = 0;
unsigned char i = 0;
for(i=0;i < data_server_index; i++)fputc(BUFF_DATA_RECEIVE_SERVER[i],DEBUG);
//fprintf(DEBUG,"\n\rEase Buffer SERVER: \n\r");
for(i=0;i < MAX_DATA_RECEIVE_FROM_SERVER; i++){
BUFF_DATA_RECEIVE_SERVER[i] = 0;
}

data_server_index = 0;
return(temp_check_bolean);
}
