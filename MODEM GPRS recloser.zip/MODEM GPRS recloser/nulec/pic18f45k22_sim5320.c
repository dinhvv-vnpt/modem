#include "pic18f45k22_sim5320.h"
#include <stdio.h>
#include <stdlib.h>
#include "process.c"
#include "load_data.c"
#include "send_TCP.c"
//==============================================================================
#int_timer1
void  TIMER1_isr(VOID){
   output_toggle(PIN_A1);
   set_timer1(65535-23150);   // ngat xay ra sau 100ms
  if(time_max_connect>15)
       {
       reset_cpu();
       }
       
//   RESERT_WATCH_DOG;
//   fprintf (DEBUG, "\n\rST: %u\r",tick_second);
//PIN_DTR_TOGGLE;
   ++tick_100ms;
   //------------------------------------------------------------------------------
   IF (tick_100ms > 10){
      // xay ra sau 1second
      ++tick_second;
      ++count_to_release_timeout;
      ++count_WAIT_SECOND;
      tick_100ms = 0;
      // restart_wdt () ;
   }//-------------------------------------------------------
   IF (tick_second > 59){
      // xay ra sau 1 minute
      ++tick_minute;
      ++count_WAIT_MINUTE;
      time_max_connect++;
      tick_second = 0;
      FLAG_5_MINUTE = 1;
   }//-------------------------------------------------------
}
//==============================================================================
#INT_RDA
void RDA_PICETH(){
unsigned char value;
disable_interrupts(INT_TIMER1);
value = fgetc(PICETH);
//fputc(value,DEBUG);
if(STATE_TCP == TCP_CONNECT){COUNT_CHANGE_TASK = 0;fputc (value, PORT1) ;}
enable_interrupts(INT_TIMER1);
}
//==============================================================================
#INT_RDA2
void  RDA_isr(VOID){
   UNSIGNED char value;
   disable_interrupts(INT_TIMER1);
   value = fgetc (PORT1) ;
  time_max_connect=0;
  //  fputc(value,DEBUG);
   if(STATE_TCP == TCP_CONNECT){
      COUNT_CHANGE_TASK = 0;
     // fputc (value, PICETH) ;
    //     fputc(value,DEBUG);
   }
   ERROR_LED_ON;
   switch(value){
      case 'O':{
          wait_OK_IRA = 1;
      break;
      }
      case 'K':{ 
          IF (wait_OK_IRA == 1) wait_OK_from_ME = 0;   
      break;
      }
      case '#':{
         IF ((DEVICE_STATE == DEVICE_CHECK_SMS)&&(FLAG_SMS_SUCCESS ==0)&&(FLAG_SMS_START == 1)){FLAG_SMS_SUCCESS = 1;L_O_BUFF = sms_index;}  
         
      break;
      }
      case '\r':{
    //     wait_OK_IRA = 0;
         break;
      }
      case '"':{
         switch(DEVICE_STATE){
            case DEVICE_CHECK_SMS:{
               IF (FLAG_SMS_START == 0)FLAG_SMS_START = 1; 
            break;
            }
          
         }
         break;
      } 
      case ':':{
               
      break;
      }
      case 'C':{
               IF ((DEVICE_STATE == DEVICE_READY)&&(STATE_TCP == TCP_CONNECT || STATE_TCP == TCP_START)&&(FLAG_DATA_FROM_SERVER_START == 0)){FLAG_DATA_FROM_SERVER_START = 1;data_temp_index = 0;}
      break;
      } 
      case '\n':{
         break;
      }
      default : {
         break;
      }
   }
//-------------------------------------------------   
         switch(DEVICE_STATE){
            case DEVICE_CHECK_SMS:{
                  IF ((FLAG_SMS_START == 1)&& (FLAG_SMS_SUCCESS == 0)){
                     BUFF_DATA_SMS[sms_index] = value; sms_index++;  
                  }
                 break;
            } 
            case DEVICE_READY:{ 
            if((FLAG_DATA_FROM_SERVER_START == 1) && (data_temp_index < 6)) {BUFF_DATA_TEMP[data_temp_index] = value;data_temp_index++;}
            BUFF_DATA_RECEIVE_SERVER[data_server_index] = value; data_server_index++;  
                 
            break;
            }
        }
        if((data_temp_index == 6) && (FLAG_DATA_FROM_SERVER_START == 1)){FLAG_DATA_FROM_SERVER_SUCCESS = 1;}
   enable_interrupts(INT_TIMER1);
}
//==============================================================================

void main(){
   enable_interrupts (INT_TIMER1);
   enable_interrupts(INT_RDA);
   enable_interrupts(INT_RDA2);
   setup_timer_1 (T1_INTERNAL|T1_DIV_BY_8); //104 ms overflow
   enable_interrupts (GLOBAL);
   //----------------------------------------------
   // LOAD THONG SO CAU HINH HOAT DONG CHO THIET BI
   LoadData () ;
   //----------------------------------------------
 
   fprintf (DEBUG, "\n\rSTART DEBUG: \n\r");
   //power_on_sim5218();

//   UNSIGNED char i = 0;
//   FOR (i = 0; i < 15; i++) {
//         Reset_PICETH();
//         fprintf(PORT1,"AT\r");
//         fprintf(DEBUG,"RESET PIC ETHERNET\r\n");
//         WAIT_SECOND(20);
//   }
   fprintf (DEBUG, "\n\rINIT\n\r") ;
//   DEVICE_STATE = DEVICE_READY;
   DEVICE_STATE = DEVICE_CONFIG;
//   DEVICE_STATE = DEVICE_REQUEST_PICETH;
   DEVICE_STARTUP = POWER_DOWN;
   STATE_TCP = TCP_IDLE;
   PIN_DTR_ON;
   
   WHILE (TRUE){
      SWITCH (DEVICE_STATE) {
//------------------------------------------------------
         CASE DEVICE_CHECK_SMS:{
         check_function_operation = 0;
         COUNT_CHANGE_TASK = 0;
            READ_SMS();
            IF (FLAG_SMS_SUCCESS){
               fprintf (DEBUG, "\n\rCheck SMS syntax: \n\r") ;
               
               SMS_PROCESS () ;
               
               FLAG_SMS_SUCCESS = 0;
;
            check_function_operation = SEND_SMS_TO_USER();
            }
            IF (FLAG_SMS_START){
               DELETE_ALL_SMS();
            }
             //  prepare_for_check_OK();
               //fprintf(PORT1,"AT+CIPMODE=1\r");
             //  check_function_operation = check_OK_from_ME();
              IF (check_function_operation == 0){DEVICE_STATE = DEVICE_READY; }
              IF (check_function_operation == 1){DEVICE_STATE = DEVICE_ERROR; BEFORE_STATE = DEVICE_CHECK_SMS; }
         break;
         
         }//-------------------------------------------------------------------
         CASE DEVICE_READY:{
         ERROR_LED_OFF;
            //LIEN TUC GIAM SAT TCP
            count_ERROR = 0;
            if(FLAG_DATA_FROM_SERVER_SUCCESS == 1){      // NHAN DUOC CLOSED
               Process_Data_From_Server();
               FLAG_DATA_FROM_SERVER_SUCCESS = 0;
            }
            if(STATE_TCP != TCP_CONNECT) FLAG_SEND_DATA_TO_RECLOSER = 0;
//            fprintf (PIC_ETH, "\n\rCheck Interface Pic Ethernet: \n\r") ;
            // THU DUOC DU LIEU TU COM2 THI DAY NGAY LEN SERVER
            check_function_operation = Connect_TCP();
            // CO DU LIEU TU SERVER THI GUI NGAY XUONG COM2
            WAIT_SECOND(1);
               IF (check_function_operation == 0){
                  ++COUNT_CHANGE_TASK;
                  if(COUNT_CHANGE_TASK > MAX_COUNT_CHANGE_TASK ){
                     COUNT_CHANGE_TASK = 0;
                     STATE_TCP = TCP_DISCONNECT;
                     fprintf (DEBUG, "\n\rTIMEOUT 250 SECOND\n\r") ;
                  }
                 // else DEVICE_STATE = DEVICE_READY;
               }
               IF (check_function_operation == 1){DEVICE_STATE = DEVICE_ERROR; BEFORE_STATE = DEVICE_READY; }
            break;
         }
//------------------------------------------------------
         CASE DEVICE_CONFIG:{
            fprintf (DEBUG, "\n\rDEVICE_CONFIG: \n\r") ;
            delay_ms (1000) ;
            SWITCH (DEVICE_STARTUP){
               CASE POWER_UP: {
                  //IF NGUON CHUA DUOC BAT = > BAT NGUON
                  fprintf (DEBUG, "\n\rPower Up: \n\r") ;
                  //WAIT_SECOND (3) ;
                  power_on_sim5218 ();
                  //DEVICE_STARTUP = POWER_DOWN;

                  check_function_operation = check_device_POWER_ON ();
                  IF (check_function_operation == 0){DEVICE_STARTUP = CONFIG_DEVICE; }
                  IF (check_function_operation == 1){DEVICE_STATE = DEVICE_ERROR; BEFORE_STATE = DEVICE_CONFIG; BEFORE_STARTUP = POWER_UP;}
                  BREAK;
               }
               CASE POWER_DOWN: {
                  check_function_operation = 0;
                  fprintf (DEBUG, "\n\rPower Down: \n\r") ;
                  WAIT_SECOND (3) ;
                  check_function_operation = check_device_POWER_ON ();
                  
                  IF (check_function_operation == 0){DEVICE_STARTUP = CONFIG_DEVICE; } // THIET BI DA HOAT DONG
                  IF (check_function_operation == 1){DEVICE_STARTUP = POWER_UP; }  // KICH HOAT THIET BI
                  BREAK;
               }
               CASE CONFIG_DEVICE:{
                  // thuc hien mot lan khi bat nguon
                  fprintf (DEBUG, "\n\rConfig Device: \n\r") ;
                  //WAIT_SECOND (3) ;
                  check_function_operation = 0;
                  check_function_operation = config_module_sim5218 ();
                  IF (check_function_operation == 0){DEVICE_STATE = DEVICE_CHECK_SMS; }
                  IF (check_function_operation == 1){DEVICE_STATE = DEVICE_ERROR; BEFORE_STATE = DEVICE_CONFIG; BEFORE_STARTUP = CONFIG_DEVICE; }
                  BREAK;
               }
            }
            break;
         }
         CASE DEVICE_ERROR:{
            fprintf (DEBUG, "\n\rDevice Error: \n\r") ;
          //  output_low (ERROR_LED) ;
            WAIT_SECOND (3) ;
            ++count_ERROR;
            DEVICE_STATE = BEFORE_STATE;
            DEVICE_STARTUP = BEFORE_STARTUP;
            // TAT THIET BI VA RESET CUNG
            IF (count_ERROR == MAX_COUNT_ERROR){count_ERROR = 0; DEVICE_STATE = RESET_MODULE_SIM; }
            break;
         }
         CASE RESET_MODULE_SIM:{
            fprintf (DEBUG, "\n\rReset Device: \n\r") ;
            WAIT_SECOND (3) ;
            reset_module (); // TAT NGUON MODULE
            reset_cpu (); // BAT LAI MODULE
            break;
         }
         CASE RESTORE_DEAULT:{
            break;
         }
      }
   }
}

