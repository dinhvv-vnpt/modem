int1 power_on_sim5218(){
int1 temp_check_bolean = 0;
fprintf(DEBUG,"\n\rPOWER ON: \n\r");
   SWITCH_POWER_ON;
   WAIT_SECOND(2);
   SWITCH_POWER_OFF;
   WAIT_SECOND(30);

//   temp_check_bolean = check_device_POWER_ON();
return(temp_check_bolean);
}
//------------------------------------------------------------------------------
int1 check_device_POWER_ON(){
int1 temp_check_bolean = 0;
fprintf(DEBUG,"\n\rCHECK SIM ON: \n\r");
   prepare_for_check_OK();
//!   fprintf(PORT1,"AT\r");
//!   WAIT_SECOND(2);
//!   fprintf(PORT1,"AT\r");
//!   WAIT_SECOND(2);
//!   fprintf(PORT1,"AT\r");
//!   WAIT_SECOND(2);
   fprintf(PORT1,"AT\r");
   WAIT_SECOND(2);
   fprintf(PORT1,"AT+CPAS\r");
   temp_check_bolean = check_OK_from_ME();
   return(temp_check_bolean);
}
//------------------------------------------------------------------------------
int1  WAIT_SECOND(unsigned int8 second){
count_WAIT_SECOND = 0;   
   while(count_WAIT_SECOND < second);
   return(1);
}
//------------------------------------------------------------------------------
void prepare_for_check_OK(){
//---------------------------------------------   
   wait_OK_IRA = 0;
   wait_OK_from_ME = 1;
   count_to_release_timeout = 0;
}
//------------------------------------------------------------------------------
int1 check_OK_from_ME(){
   int1 temp_return = 0;
   while(wait_OK_from_ME){  // CHI GIAI PHONG KHI NHAN DUOC OK TU MODULE HOAC SAU TIMEOUT
      if(count_to_release_timeout > TIMEOUT){ // TIMEOUT SAU 5s 
         temp_return = 1;
         blink_led(10,100);      
         break;
         }
   }
   blink_led(4,500); 
   return(temp_return);   
}
//------------------------------------------------------------------------------
int1 config_module_sim5218(){
int1 temp_check_bolean = 0;
   WAIT_SECOND(2);
   prepare_for_check_OK();
   if(temp_check_bolean == 0){
   prepare_for_check_OK();
   fprintf(PORT1,"AT+CMGF=1\r");// TAT BO CHE DO ECHO LENH
   fprintf(DEBUG,"\n\rAT+CMGF=1 \n\r");
   temp_check_bolean = check_OK_from_ME();
   }
 
   if(temp_check_bolean == 0){   // CHI CHON WCDMA
      prepare_for_check_OK();
//!      fprintf(PORT1,"AT+IPR=115200\r"); // 
//!      fprintf(DEBUG,"AT+IPR=115200\r"); 
      fprintf(DEBUG,"\n\rAT+IPREX=9600\n\r"); 
      fprintf(PORT1,"AT+IPREX=9600\r"); // DAT TOC DO BAUD VA CO DINH TOC DO
      temp_check_bolean = check_OK_from_ME();
     
   }

   if(temp_check_bolean == 0){   // CHI CHON WCDMA
      prepare_for_check_OK();
      fprintf(PORT1,"ATE0\r"); // LUA CHON MANG 3G
      fprintf(DEBUG,"\n\rATE0 \n\r");
      temp_check_bolean = check_OK_from_ME();
   }
   
   if(temp_check_bolean == 0){   // CHI CHON WCDMA
      prepare_for_check_OK();
      fprintf(PORT1,"AT&W\r"); // LUA CHON MANG 3G
      fprintf(DEBUG,"\n\rAT&W \n\r"); 
      temp_check_bolean = check_OK_from_ME();
   }
   return(temp_check_bolean);
}
//------------------------------------------------------------------------------
int1 reset_module(){
   SWITCH_POWER_ON;
   WAIT_SECOND(2);
   SWITCH_POWER_OFF;
   WAIT_SECOND(5);
   return(check_OK_from_ME());
}
//------------------------------------------------------------------------------
int1  WAIT_MINUTE(unsigned int8 minute){
count_WAIT_MINUTE = 0;
   while(count_WAIT_MINUTE < minute);
   return(1);
}
//------------------------------------------------------------------------------
int1 check_sim_operation(){
int1 temp_check_bolean = 0;
  prepare_for_check_OK();
  fprintf(PORT1,"AT\r");
  temp_check_bolean = check_OK_from_ME();
  return(temp_check_bolean);
}
//------------------------------------------------------------------------------
void SMS_PROCESS(){
unsigned char i =0,index_num=0,index_phone = 0,index_sms = 0,h=0;

   for(i=0;i < L_O_BUFF; i++){
      if((BUFF_DATA_SMS[i]=='"')||((BUFF_DATA_SMS[i]=='*')))index_num++;
      if((index_num == 3)&&(BUFF_DATA_SMS[i]!='"')&&(BUFF_DATA_SMS[i]!='*')&&(BUFF_DATA_SMS[i]!=0x13)&&(BUFF_DATA_SMS[i]!=0x10)){
         PHONE_NUMBER[index_phone] = BUFF_DATA_SMS[i];
         //---------------------------------------
         fputc(PHONE_NUMBER[index_phone], DEBUG);
         //---------------------------------------
         index_phone++;
         L_O_PHONE = index_phone;
       }
      if((index_num == 8)&&(BUFF_DATA_SMS[i]!= 13)&&(BUFF_DATA_SMS[i]!= 10)&&(BUFF_DATA_SMS[i]!='"')&&(BUFF_DATA_SMS[i]!='*')){
         DATA_SMS[index_sms]=BUFF_DATA_SMS[i];
         //---------------------------------------
         fputc(DATA_SMS[index_sms], DEBUG);
         //---------------------------------------
         index_sms++;  
         L_O_SMS = index_sms; 
      }
      if(BUFF_DATA_SMS[i]=='#'){   break;}
   
   }

   
   if(FLAG_ADMIN_FUN==1){
      //-----so admin----------
   fprintf(DEBUG,"\n\rCheck user : \n\r");
      for(i=0;i<L_O_PHONE;i++){
         if(PHONE_NUMBER[i]==NUM_PHONE1[i]) h++;
      }  // ADMIN DA NHAN TIN VAO HE THONG
      if(h==L_O_PHONE){FLAG_ADMIN_ACCESS = 1;h=0;
         fprintf(DEBUG,"\n\rAdmin access: \n\r");
      }  // KHONG PHAI ADMIN DANG NHAP VAO HE THONG
      else {FLAG_ADMIN_ACCESS=0;h=0;}
      for(i=0;i<L_O_PHONE;i++){
         if(PHONE_NUMBER[i]==NUM_PHONE2[i]) h++;
      }
      if(h==L_O_PHONE){FLAG_USER_ACCESS = 1;//Num_user=1;
         fprintf(DEBUG,"\n\rUser access: \n\r");
      }
      else {h=0;}
      for(i=0;i<L_O_PHONE;i++){
         if(PHONE_NUMBER[i]==NUM_PHONE3[i]) h++;
      }
      if(h==L_O_PHONE){FLAG_USER_ACCESS = 1;//Num_user=1;
         fprintf(DEBUG,"\n\rUser access: \n\r");
      }
      else {h=0;}
   }
SMS_STATE = SMS_IDLE;
if((FLAG_ADMIN_FUN == 1)&&((FLAG_ADMIN_ACCESS==1)||(FLAG_USER_ACCESS == 1))||(FLAG_ADMIN_FUN == 0)){
   fprintf(DEBUG,"\n\rCheck Condition: \n\r");
//----------
   // THIET LAP PASS LOGIN THIET BI       OK
   if((DATA_SMS[0] == 'S')&&(DATA_SMS[3] == 'P')&&(DATA_SMS[4] == 'A')&&(DATA_SMS[8] == PASS_LOGIN[0])&&(DATA_SMS[9] == PASS_LOGIN[1])&&(DATA_SMS[10] == PASS_LOGIN[2])&&(DATA_SMS[11] == PASS_LOGIN[3])){SMS_STATE = SET_PASS;}
   // THIET LAP IP SERVER                 OK
   if((DATA_SMS[0] == 'S')&&(DATA_SMS[3] == 'D')&&(DATA_SMS[4] == 'N')&&(DATA_SMS[7] == PASS_LOGIN[0])&&(DATA_SMS[8] == PASS_LOGIN[1])&&(DATA_SMS[9] == PASS_LOGIN[2])&&(DATA_SMS[10] == PASS_LOGIN[3])){SMS_STATE = SET_DNS;}
   // THIET LAP CHE DO TRUY CAP           OK
   if((DATA_SMS[0] == 'S')&&(DATA_SMS[3] == 'F')&&(DATA_SMS[4] == 'U')&&(DATA_SMS[8] == PASS_LOGIN[0])&&(DATA_SMS[9] == PASS_LOGIN[1])&&(DATA_SMS[10] == PASS_LOGIN[2])&&(DATA_SMS[11] == PASS_LOGIN[3])){SMS_STATE = SET_FUNCTION;}
   // THIET LAP THONG SO VAO MANG GPRS    OK
   if((DATA_SMS[0] == 'S')&&(DATA_SMS[3] == 'G')&&(DATA_SMS[4] == 'P')&&(DATA_SMS[8] == PASS_LOGIN[0])&&(DATA_SMS[9] == PASS_LOGIN[1])&&(DATA_SMS[10] == PASS_LOGIN[2])&&(DATA_SMS[11] == PASS_LOGIN[3])){SMS_STATE = SET_GPRS;} // OK
   // THIET LAP ID CUA THIET BI           OK
   if((DATA_SMS[0] == 'S')&&(DATA_SMS[3] == 'I')&&(DATA_SMS[4] == 'D')&&(DATA_SMS[6] == PASS_LOGIN[0])&&(DATA_SMS[7] == PASS_LOGIN[1])&&(DATA_SMS[8] == PASS_LOGIN[2])&&(DATA_SMS[9] == PASS_LOGIN[3])){SMS_STATE = SET_ID;}
   // THIET LAP THONG SO FTP CUA THIET BI           OK
   if((DATA_SMS[0] == 'S')&&(DATA_SMS[3] == 'F')&&(DATA_SMS[4] == 'T')&&(DATA_SMS[7] == PASS_LOGIN[0])&&(DATA_SMS[8] == PASS_LOGIN[1])&&(DATA_SMS[9] == PASS_LOGIN[2])&&(DATA_SMS[10] == PASS_LOGIN[3])){SMS_STATE = SET_FTP;} 
   // THIET LAP THONG SO FILE FIRMWARE CUA THIET BI           OK
   if((DATA_SMS[0] == 'S')&&(DATA_SMS[3] == 'F')&&(DATA_SMS[4] == 'I')&&(DATA_SMS[8] == PASS_LOGIN[0])&&(DATA_SMS[9] == PASS_LOGIN[1])&&(DATA_SMS[10] == PASS_LOGIN[2])&&(DATA_SMS[11] == PASS_LOGIN[3])){SMS_STATE = SET_FILE;}    
   // THIET LAP SO DIEN THOAI DUOC PHEP TRUY CAP
   if((DATA_SMS[0] == 'S')&&(DATA_SMS[3] == 'P')&&(DATA_SMS[4] == 'H')&&(DATA_SMS[9] == PASS_LOGIN[0])&&(DATA_SMS[10] == PASS_LOGIN[1])&&(DATA_SMS[11] == PASS_LOGIN[2])&&(DATA_SMS[12] == PASS_LOGIN[3])){SMS_STATE = SET_PHONE;}
   // THIET LAP THOI GIAN THUC CHO THIET BI OK
   if((DATA_SMS[0] == 'S')&&(DATA_SMS[3] == 'T')&&(DATA_SMS[4] == 'I')&&(DATA_SMS[8] == PASS_LOGIN[0])&&(DATA_SMS[9] == PASS_LOGIN[1])&&(DATA_SMS[10] == PASS_LOGIN[2])&&(DATA_SMS[11] == PASS_LOGIN[3])){SMS_STATE = SET_TIME;}
   // THIET LAP CAC THONG SO HOAT DONG CUA THIET BI
}
//---------------------------------------------------
      switch(SMS_STATE){
                  case SET_FILE: {
                  unsigned char dem_sms=0,file_dem = 0;
                  fprintf(DEBUG,"\n\rSET FILE FIRMWARE: \n\r");
                  for(h=0;h<L_O_SMS;h++){
                     if(DATA_SMS[h] == '#') break;
                     if(DATA_SMS[h]==' ') dem_sms++;
                     if((dem_sms==2)&&(DATA_SMS[h]!=' ')){
                        FILE_FTP[file_dem]=DATA_SMS[h];
                        fputc(FILE_FTP[file_dem],DEBUG) ;
                        file_dem++;
                        L_O_FILE_FTP=file_dem;
                     }
                  }
                  for(h=0;h<L_O_FILE_FTP;h++){write_eeprom(ADD_FILE_FTP+h,FILE_FTP[h]);}
                  write_eeprom(ADD_L_O_FILE_FTP,L_O_FILE_FTP);                     
                  break;
                  
                  }//-----------------------------------------------------------
                  case SET_FTP: {
                  unsigned char dem_sms=0,user_dem = 0,pass_dem = 0;
                  fprintf(DEBUG,"\n\rSET FTP: \n\r");
                  for(h=0;h<L_O_SMS;h++){
                     if(DATA_SMS[h] == '#') break;
                     if(DATA_SMS[h]==' ') dem_sms++;
                     if((dem_sms==2)&&(DATA_SMS[h]!=' ')){
                        USER_FTP[user_dem]=DATA_SMS[h];
                        fputc(USER_FTP[user_dem],DEBUG) ;
                        user_dem++;
                        L_O_USER_FTP=user_dem;
                     }
                     if((dem_sms==3)&&(DATA_SMS[h]!=' ')){
                        PASS_FTP[pass_dem]=DATA_SMS[h];
                        fputc(PASS_FTP[pass_dem],DEBUG) ;
                        pass_dem++;
                        L_O_PASS_FTP = pass_dem;
                     }
                    } 
                  for(h=0;h<L_O_USER_FTP;h++){write_eeprom(ADD_USER_FTP+h,USER_FTP[h]);}  
                  for(h=0;h<L_O_PASS_FTP;h++){write_eeprom(ADD_PASS_FTP+h,PASS_FTP[h]);}
                  
                  write_eeprom(ADD_L_O_USER_FTP,L_O_USER_FTP);
                  write_eeprom(ADD_L_O_PASS_FTP,L_O_PASS_FTP);
                 
                  break;
                  }//-----------------------------------------------------------
                  case SET_PASS: {
                     unsigned char dem_sms=0,passlogin_dem=0;
                     fprintf(DEBUG,"\n\rSET PASS:\n\r");
                     for(h=0;h<L_O_SMS;h++){
                     if(DATA_SMS[h]=='#')break;
                           if(DATA_SMS[h]==' ') dem_sms++;
                           if((dem_sms==2)&&(DATA_SMS[h]!=' ')){
                              PASS_LOGIN[passlogin_dem]=DATA_SMS[h];
                              passlogin_dem++;
                           }    
                     }
                     if(passlogin_dem>4){
                        FLAG_SEND_SMS = 1;    
                     break;
                     }
                     fprintf(DEBUG,"\n\rNEW PASS:\n\r");                 
                     for(h=0;h<passlogin_dem;h++){
                        
                        write_eeprom(ADD_PASS_LOGIN+h,PASS_LOGIN[h]);
                        delay_ms(100);
                        PASS_LOGIN[h] = read_eeprom(ADD_PASS_LOGIN+h);
                        delay_ms(100);
                        fputc(PASS_LOGIN[h],DEBUG) ;
                     }
                  break;
                }
         //------------------------------------------------------       
                  case SET_GPRS:{                           //SET_GPRS
                  unsigned char apn_dem=0,dem_sms=0,user_dem = 0,pass_dem = 0;
                  fprintf(DEBUG,"\n\rSET GPRS:\n\r"); 
                  for(h=0;h<L_O_SMS;h++){
                     if(DATA_SMS[h] == '#') break;
                     if(DATA_SMS[h]==' ') dem_sms++;
                     if((dem_sms==2)&&(DATA_SMS[h]!=' ')){
                        APN_GPRS[apn_dem]=DATA_SMS[h];
                        fputc(APN_GPRS[apn_dem],DEBUG) ;
                        apn_dem++;
                        L_O_APN=apn_dem;
                     }
                     if((dem_sms==3)&&(DATA_SMS[h]!=' ')){
                        USER_GPRS[user_dem]=DATA_SMS[h];
                        fputc(USER_GPRS[user_dem],DEBUG) ;
                        user_dem++;
                        L_O_USER_GPRS = user_dem;
                     }
                     if((dem_sms==4)&&(DATA_SMS[h]!=' ')){
                        PASS_GPRS[pass_dem]=DATA_SMS[h];
                        fputc(PASS_GPRS[pass_dem],DEBUG);
                        pass_dem++;
                        L_O_PASS_GPRS = pass_dem;
                     }
                  }
                
                  for(h=0;h<L_O_APN;h++){write_eeprom(ADD_APN_GPRS+h,APN_GPRS[h]);}  
                  for(h=0;h<L_O_USER_GPRS;h++){write_eeprom(ADD_USER_GPRS+h,USER_GPRS[h]);}
                  for(h=0;h<L_O_PASS_GPRS;h++){write_eeprom(ADD_PASS_GPRS+h,PASS_GPRS[h]);}
                  write_eeprom(ADD_L_O_APN,L_O_APN);
                  write_eeprom(ADD_L_O_USER_GPRS,L_O_USER_GPRS);
                  write_eeprom(ADD_L_O_PASS_GPRS,L_O_PASS_GPRS);
                  
                  break;
                  }
       //---------------------------------------------------           
                  case SET_ID:{
                  unsigned char     dem_sms=0,id_dem=0;  
                  fprintf(DEBUG,"\n\rSET ID:\n\r");        //test
                  for(h=0;h<L_O_SMS;h++){
                     if(DATA_SMS[h]=='#')break;
                     if(DATA_SMS[h]==' ') dem_sms++;
                     if((dem_sms==2)&&(DATA_SMS[h]!=' ')){
                        ID_GPRS[id_dem]=DATA_SMS[h];
                        fputc(ID_GPRS[id_dem],DEBUG) ;
                        id_dem++;
                        L_O_ID = id_dem;
                     }    
                  }
                  for(h=0;h<id_dem;h++){write_eeprom(ADD_ID+h,ID_GPRS[h]);}
                     write_eeprom(ADD_L_O_ID,L_O_ID);// Num_ID= id_dem;
                     FLAG_SEND_SMS = 1;
                  break;
                  }
                  case SET_DNS: {      //IP SERVER VA PORT LISTEN
                  unsigned char dem_sms=0,dns_dem1=0,port_dem=0;
                  fprintf(DEBUG,"\n\rSET DNS:\n\r");  ////test
                  for(h=0;h<L_O_SMS;h++){
                     if(DATA_SMS[h]=='#')break;
                     if(DATA_SMS[h]==' ') dem_sms++;
                     if((dem_sms==2)&&(DATA_SMS[h]!=' ')){
                        DNS_SERVER[dns_dem1]=DATA_SMS[h];
                        fputc(DNS_SERVER[dns_dem1],DEBUG) ;
                        dns_dem1++;
                        L_O_DNS = dns_dem1;
                     } 
                     if((dem_sms==3)&&(DATA_SMS[h]!=' ')){
                        PORT_GPRS[port_dem]=DATA_SMS[h];
                        fputc(PORT_GPRS[port_dem],DEBUG) ;
                        port_dem++;
                        L_O_PORT = port_dem;
                     }
                  }
                  for(h=0;h<L_O_PORT;h++){write_eeprom(ADD_PORT_SERVER+h,PORT_GPRS[h]);} 
                  for(h=0;h<L_O_DNS;h++){write_eeprom(ADD_DNS+h,DNS_SERVER[h]);}
                     write_eeprom(ADD_L_O_DNS,L_O_DNS);
                     write_eeprom(ADD_L_O_PORT,L_O_PORT);
                  FLAG_SEND_SMS = 1;
                  break;
               }
               case SET_FUNCTION: { 
               unsigned char dem_sms = 0,mode_admin = 0;
               fprintf(DEBUG,"\n\rSET MODE: \n\r"); 
               for(h=0;h<L_O_SMS;h++){
                     if(DATA_SMS[h]=='#')break;
                     if(DATA_SMS[h]==' ') dem_sms++;
                     if((dem_sms==2)&&(DATA_SMS[h]!=' ')){
                        mode_admin = DATA_SMS[h];
                        fputc(mode_admin,DEBUG) ;
                        break;
                     } 
               }
               write_eeprom(ADD_ADMIN_FUN,mode_admin);
               break;
               }
               case SMS_IDLE: { 
               
               break;
               }
               case SET_TIME: { 
               unsigned char h_time = 0,dem_sms = 0,dem_time = 0;
               fprintf(DEBUG,"\n\rSET TIME: \n\r"); 
               for(h_time=0; h_time < L_O_SMS; h_time++){
              // fputc(DATA_SMS[h_time],DEBUG) ;
                     if(DATA_SMS[h_time]=='#')break;
                     if(DATA_SMS[h_time]==' ') dem_sms++;
                     if((dem_sms==2)&&(DATA_SMS[h_time]!=' ')){
                        TIME_GPRS[dem_time] = DATA_SMS[h_time];
                        fputc(TIME_GPRS[dem_time],DEBUG) ;
                        dem_time++;
                     } 
               }
               break;
               }
            }
            
}
//------------------------------------------------------------------------------
int SEND_SMS_TO_USER(){
int1 temp_check_bolean = 0;
unsigned char j=0;
  prepare_for_check_OK();
//fprintf(PORT1,"AT+CMGS=\"0984829886\"\r");
  fprintf(PORT1,"AT+CMGS=\""); 
  for(j = 0; j < L_O_PHONE; j++) fputc(PHONE_NUMBER[j],PORT1);
  fprintf(PORT1,"\"");
  fputc(13,PORT1) ;
  WAIT_SECOND(2);
   switch(SMS_STATE){
      case SET_FILE: {
         fprintf(PORT1,"FILE FTP: ");
         for(j=0;j<L_O_FILE_FTP;j++)fputc(FILE_FTP[j],PORT1) ;
      break;
      }
      case SET_FTP:{ 
         fprintf(PORT1,"USER FTP: ");
         for(j=0;j<L_O_USER_FTP;j++)fputc(USER_FTP[j],PORT1) ;
         fprintf(PORT1,"\n\rPASS FTP: ");
         for(j=0;j<L_O_PASS_FTP;j++)fputc(PASS_FTP[j],PORT1) ;
      break;
      }
      case SET_PASS: {
         fprintf(PORT1,"NEW PASS: ");
         for(j=0;j<4;j++)fputc(PASS_LOGIN[j],PORT1) ;
      break;
      }
      case SET_GPRS:{ 
         fprintf(PORT1,"APN: ");
         for(j=0;j<L_O_APN;j++)fputc(APN_GPRS[j],PORT1) ;
         fprintf(PORT1,"USER: ");
         for(j=0;j<L_O_USER_GPRS;j++)fputc(USER_GPRS[j],PORT1) ;
         fprintf(PORT1,"PASS: ");
         for(j=0;j<L_O_PASS_GPRS;j++)fputc(PASS_GPRS[j],PORT1) ;
      break;
      }
      case SET_ID:{
         fprintf(PORT1,"NEW ID: ");
         for(j=0;j<L_O_ID;j++)fputc(ID_GPRS[j],PORT1) ;
      break;
      }
      case SET_DNS:{
         fprintf(PORT1,"DNS SERVER: ");
         for(j=0;j<L_O_DNS;j++)fputc(DNS_SERVER[j],PORT1) ;
         fprintf(PORT1,"\n\rPORT: ");
         for(j=0;j<L_O_PORT;j++)fputc(PORT_GPRS[j],PORT1) ;
      break;
      }
      case SMS_IDLE: { 
               
      break;
      }
   }
  SMS_STATE = SMS_IDLE;
  WAIT_SECOND(1); 
  fputc(26,PORT1) ;
  temp_check_bolean = check_OK_from_ME();
  return(temp_check_bolean);
}
//------------------------------------------------------------------------------
int1 READ_SMS(){
int1 temp_check_bolean = 0;
unsigned char i = 0;
   fprintf(DEBUG,"\n\rEase Buffer: \n\r");
   for(i=0;i < 200; i++){
   BUFF_DATA_SMS[i] = 0;
   }
   FLAG_SMS_START = 0;
   FLAG_SMS_SUCCESS = 0;
   sms_index = 0;
//!         
//!            prepare_for_check_OK();
//!            fprintf(PORT1,"AT+CIPMODE=0\r");
//!            temp_check_bolean = check_OK_from_ME();
         
 //  if(temp_check_bolean == 0){ 
      prepare_for_check_OK();
      fprintf(PORT1,"AT+CMGR=0\r"); // DOC TIN NHAN TAI O NHO THU NHAT
      WAIT_SECOND(1);
      temp_check_bolean = check_OK_from_ME();
//   }
return(temp_check_bolean);
}
//------------------------------------------------------------------------------
int1 DELETE_ALL_SMS(){
int1 temp_check_bolean = 0;
  prepare_for_check_OK();
  fprintf(PORT1,"AT+CMGD=0,4\r"); // LUA CHON MANG 3G
  WAIT_SECOND(1);
  temp_check_bolean = check_OK_from_ME();
return(temp_check_bolean);
}
